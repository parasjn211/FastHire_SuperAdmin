package com.fasthire.SuperAdmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
