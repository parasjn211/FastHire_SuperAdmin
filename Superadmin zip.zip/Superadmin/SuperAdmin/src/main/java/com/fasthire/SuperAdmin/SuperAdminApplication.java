package com.fasthire.SuperAdmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperAdminApplication.class, args);
	}

}
