package com.fasthire.SuperAdmin.repository;

import com.fasthire.SuperAdmin.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
}

