package com.fasthire.SuperAdmin.entity;

public enum Gender {
    MALE, FEMALE, OTHER
}
