package com.fasthire.SuperAdmin.repository;

import com.fasthire.SuperAdmin.entity.JobPost;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobPostRepository extends JpaRepository<JobPost, Long> {
}
